# Economic Calendar: JavaFX handoff package

This folder has everything needed to rebuild the Economic Calendar web prototype as a **JavaFX module inside your existing app**, working with Claude.

## How to use it

1. Copy this whole `javafx-handoff/` folder into the root of the existing JavaFX app's repository.
2. Open Claude Code at the repository root.
3. Paste the **opening prompt** from `HANDOFF.md` (section 0).
4. Claude will first inspect your codebase and propose how the module plugs in. Review that, then let it build **one phase at a time** (`HANDOFF.md` §15).
5. After each phase, run that phase's checks in `tests.md`. Tell Claude about anything that doesn't match before moving on.

## What's inside

| Item | Purpose |
|---|---|
| `HANDOFF.md` | The full specification and build plan, written for Claude |
| `DATA-SERVER.md` | **How data flows:** our server is the only Finnhub caller, and clients poll it. Read this first; it overrides `HANDOFF.md` §4 and §9 |
| `DEPLOY-APP-ENGINE.md` | How to run that server on Google App Engine: cron schedule, Cloud Storage, Secret Manager, `app.yaml`, setup steps, costs |
| `tests.md` | Acceptance checks with exact expected values from the sample data |
| `screenshots/` | The look to match (17 images, dark and light) |
| `reference/` | The web prototype's source: reference only, for exact rules and wording |
| `assets/` | Inter TTF fonts, 271 flag PNGs and SVG icon paths, all bundled (no outside requests) |
| `test-data/` | A real calendar response for tests and offline development |

## Decisions for you (the developer)

- **API key handling:** `HANDOFF.md` §4.2 lists the options (a proxy server, a bundled key, a per-client key, or your app's own licensing). The choice is yours.
- **Theme:** if your app already controls dark/light, the calendar should follow it (§11).
- **Settings storage:** use your app's settings system if it has one. Otherwise use `java.util.prefs` (§10).

## Licences of bundled assets

| Asset | Licence | File |
|---|---|---|
| Inter font | SIL Open Font License 1.1 | `assets/fonts/LICENSE-Inter-OFL.txt` |
| Country flags (rendered from flag-icons) | MIT | `assets/flags/LICENSE-flag-icons.txt` |
| Icons (from Lucide) | ISC | Keep the attribution "Icons from Lucide (ISC licence)" in your app's third-party notices |
