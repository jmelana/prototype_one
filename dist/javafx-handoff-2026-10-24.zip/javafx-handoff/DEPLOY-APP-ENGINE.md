# Running the calendar server on Google App Engine

**For:** the Java developer.
**Read first:** `DATA-SERVER.md`, which explains *what* the server does: it's the only Finnhub caller, it refreshes on a schedule, and clients poll it with ETag/304. This document explains *how* to run it on **Google App Engine (standard environment, Java 21)**.

---

## 1. What App Engine changes

On App Engine, instances start and stop automatically and there may be several at once. So the design in `DATA-SERVER.md` is kept, with three changes:

| `DATA-SERVER.md` says | On App Engine |
|---|---|
| The server runs timers (every 30 min, every 5 min, after releases) | **App Engine cron** calls internal URLs on a schedule. No background threads. |
| The server holds the snapshot in memory and on disk | **Cloud Storage** holds the single shared copy. Each instance caches it in memory. |
| The API key comes from server config | **Secret Manager** holds the key. |

## 2. Architecture

```
            App Engine cron (cron.yaml)
   ┌───────── every 30 min ── GET /tasks/full-refresh ─────────┐
   ├───────── every 5 min ─── GET /tasks/today-refresh ────────┤
   └───────── every 1 min ─── GET /tasks/release-check ────────┤
                                                               ▼
                                         ┌──────────────────────────────┐
  Secret Manager ── Finnhub key ───────► │  App Engine (Java 21)        │ ──► Finnhub
                                         │  - task handlers (above)     │
                                         │  - GET /calendar for clients │
                                         └──────┬───────────────▲───────┘
                                    write new   │               │ read (cached in
                                    version     ▼               │ memory per instance)
                                         ┌──────────────────────────────┐
                                         │ Cloud Storage (private)      │
                                         │ calendar.json.gz             │
                                         │ metadata: version, from, to, │
                                         │           updatedAt, hash    │
                                         └──────────────────────────────┘
                                                ▲
              JavaFX clients ── GET /calendar (If-None-Match) every 60 s
```

## 3. The schedule: `cron.yaml`

```yaml
cron:
- description: Full window refresh (1 month back to 2 months ahead)
  url: /tasks/full-refresh
  schedule: every 30 minutes
- description: Today ±1 day refresh
  url: /tasks/today-refresh
  schedule: every 5 minutes
- description: Refresh about 60 s after scheduled releases
  url: /tasks/release-check
  schedule: every 1 minutes
```

**Release refresh on cron.** Cron can't fire at an exact second like 08:31:00, so the release refresh becomes a once-a-minute check. It refreshes when something was scheduled 60–120 seconds ago and still has no actual value:

```java
// GET /tasks/release-check — every minute
Snapshot s = store.read();
Instant now = Instant.now();
boolean justReleased = s.events().stream().anyMatch(e ->
    e.actual() == null && e.expectsValue() && !e.isHoliday()
    && e.time().isAfter(now.minusSeconds(120))
    && !e.time().isAfter(now.minusSeconds(60)));
if (justReleased) todayRefresh();   // one Finnhub call however many releases share that minute
```

This gives the same "about one minute after a release" behaviour as `DATA-SERVER.md` §3.2, and releases in the same minute automatically share one call.

**Only cron may call `/tasks/*`.** App Engine removes this header from outside requests, so its presence proves the caller is cron:

```java
if (!"true".equals(req.header("X-Appengine-Cron"))) return status(403);
```

## 4. Shared storage: Cloud Storage

- **One private object:** `gs://<bucket>/calendar.json.gz` (gzipped JSON in the response format of `DATA-SERVER.md` §3.5).
- **Custom metadata on the object:** `version`, `from`, `to`, `updatedAt`, `hash`.
- **Full refresh:** fetch the window from Finnhub, build the JSON, hash it. **If the hash equals the stored one, don't write**, so the version stays unchanged. Otherwise write with `version + 1`.
- **Today refresh:** read the object, replace yesterday–tomorrow's events, then write **with an `ifGenerationMatch` precondition**. If another refresh wrote first, re-read and retry, so updates are never lost.
- **Errors from Finnhub:** don't write anything, and the last good object keeps being served. On a 429, skip the next few runs (back off), e.g. by recording `backoffUntil` in the object metadata.

## 5. The client endpoint: `GET /calendar`

Each instance keeps the latest snapshot in memory. It checks the object's **generation** in Cloud Storage at most every ~5 seconds (a cheap metadata read) and reloads the bytes only when the generation changed.

```java
// GET /calendar
authenticate(req);                                   // the client's app token (see §7)
Snapshot s = cache.current();                        // refreshed from Cloud Storage when its generation changes
if (s == null) return status(503);
String etag = "\"" + s.version() + "\"";
if (etag.equals(req.header("If-None-Match"))) return status(304);
return ok(s.gzippedBytes())
    .header("Content-Encoding", "gzip")
    .header("Content-Type", "application/json")
    .header("ETag", etag)
    .header("Cache-Control", "no-cache");
```

Most client polls get a **304 straight from memory**, which is very cheap.

## 6. App configuration: `app.yaml`

```yaml
runtime: java21
instance_class: F2
automatic_scaling:
  min_instances: 1          # keeps one warm instance, so client polls never wait for a cold start
  max_instances: 10
env_variables:
  DATA_BUCKET: "econocal-data"
  FINNHUB_SECRET: "projects/<project-id>/secrets/finnhub-key/versions/latest"
```

At startup, read the key with the **Secret Manager client library**, using the App Engine default service account. Never log the key or return it in any response.

Any Java web stack works: Spring Boot, Micronaut, or a plain servlet app. Use the **Google Cloud client libraries** for Cloud Storage and Secret Manager, and `java.net.http.HttpClient` for Finnhub.

## 7. Client authentication and rate limits

- Clients send their app token as `Authorization: Bearer <token>`, and the handler validates it against your licence or login system. Return 401/403 when it's missing or invalid.
- **Rate limiting:** in-memory counters aren't shared between instances. Choose one:
  - **Cloud Armor** rate-limiting rules (needs a load balancer in front of App Engine)
  - **API Gateway** or **Apigee** in front of `/calendar`
  - a per-client counter in **Memorystore (Redis)**

  Target about **one request per 10 seconds per client**. Normal clients poll every 60 seconds.

## 8. Setup steps

1. Create a Google Cloud project. Enable **App Engine**, **Cloud Storage**, **Secret Manager** and **Cloud Scheduler** (cron uses it).
2. Create the App Engine app in the region closest to your users: `gcloud app create --region=<region>`.
3. Store the key: `gcloud secrets create finnhub-key --data-file=-` (paste the key, then Ctrl+D). Grant the App Engine service account **Secret Manager Secret Accessor**.
4. Create a **private** bucket (e.g. `econocal-data`) and grant the service account **Storage Object Admin** on it.
5. Build the Java app: `/tasks/full-refresh`, `/tasks/today-refresh`, `/tasks/release-check`, `/calendar`, the Cloud Storage store and the memory cache.
6. Deploy: `gcloud app deploy app.yaml cron.yaml`.
7. Fill the data once by running the full refresh, either by waiting up to 30 minutes for cron or with a one-off admin trigger.
8. Point the JavaFX client at `https://<project-id>.appspot.com/calendar`, or at your own domain (App Engine supports custom domains with managed certificates).

## 9. Monitoring

- **Logs:** each refresh logs one line: trigger, Finnhub status, events count, version (or "unchanged").
- **Alerting (Cloud Monitoring):**
  - no successful full refresh in 2 hours
  - a Finnhub error rate spike
  - `/calendar` 5xx errors
- **Budget alerts** in Cloud Billing.

## 10. Cost (rough)

| Item | Expectation |
|---|---|
| Finnhub | About 400–500 calls a day, fixed whatever the number of clients |
| App Engine | One always-on F2 instance, plus extra instances only under heavy load. Polls are mostly 304s. Tens of dollars a month for moderate client numbers. |
| Cloud Storage, Secret Manager, cron | Pennies at this volume |

## 11. Alternative: Cloud Run

**Cloud Run** runs the same Java service as a container, with the same design: **Cloud Scheduler** instead of `cron.yaml` (authenticate its calls with an OIDC token instead of the cron header), plus Cloud Storage and Secret Manager. It's often easier to run and test locally because it's a plain container. If your organisation already uses App Engine, stay with it; both work.

## 12. Checklist

- [ ] `/tasks/*` returns 403 without the `X-Appengine-Cron` header.
- [ ] After the first full refresh, `GET /calendar` returns 200 with gzip, ETag and the `from`/`to` window.
- [ ] Repeating the request with that ETag returns **304**.
- [ ] A refresh with identical data doesn't change the version (no write).
- [ ] Two overlapping today refreshes don't lose data (generation precondition and retry).
- [ ] A release at 08:30 triggers one Finnhub call between 08:31 and 08:32.
- [ ] While Finnhub is failing, clients keep getting the last good data.
- [ ] The Finnhub key appears nowhere in code, logs or responses.
- [ ] Load test: 1,000 clients polling every 60 s cause no extra Finnhub calls and stay within budget.
