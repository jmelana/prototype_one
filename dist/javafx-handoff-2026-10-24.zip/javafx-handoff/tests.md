# Acceptance checks

The Java version must pass every check below. **T1–T6, T14–T15, T24–T30 and T33** are pure logic: write them as JUnit tests against the model and engine classes, with no JavaFX. The rest are UI checks: automate them with TestFX if the host app uses it, or check them by hand against `screenshots/`.

## Fixed setup for every check (unless a check says otherwise)

| Setting | Value |
|---|---|
| Data | `test-data/sample-calendar.json` (1,683 items, Oct 20 → Nov 10, 2026) via the fixture `CalendarDataSource` |
| Clock | **2026-10-22T16:00:00Z**, which is Thursday Oct 22, 12:00 in Toronto (inject a `Clock`, don't use the system time) |
| Display zone | **America/Toronto**; locale **en-US** |
| Settings | Fresh: nothing saved, all defaults |

The prototype produces the numbers below with this setup. Rows are counted after duplicates are removed.

---

## Phase 1: data layer

**T1. Normalising**
- 1,683 items load.
- **23** are flagged as duplicates, and they never appear or alert.
- **91** are holidays.
- Ids are `country|time|event`. A repeat of the same triple gets `#1`, `#2`…
- Events are sorted by time.

**T2. Holiday detection**
- "Dashain Holiday" (NP, 2026-10-20 00:00:00, all values null) **is** a holiday.
- An event at 00:00:00 with all values null whose name contains "Election", "plenum", "meeting", "budget" or "referendum" **is not** a holiday.
- A holiday belongs to its listed date (2026-10-20) whatever the display zone.

**T3. Categories.** Each name gives its category:

| Name | Category |
|---|---|
| Non Farm Payrolls | Employment |
| GDP Growth Rate QoQ | Growth |
| Retail Sales MoM | Growth |
| Balance of Trade | Growth |
| Atlanta Fed GDPNow | Growth |
| Inflation Rate YoY | Inflation |
| Retail Price Index YoY | Inflation |
| RBA Trimmed Mean CPI QoQ | Inflation |
| Fed Interest Rate Decision | Central Bank |
| BoJ Quarterly Outlook Report | Central Bank |
| Fed Powell Speech | Speeches |
| ECB Press Conference | Speeches |
| 10-Year Note Auction | Bonds |
| Housing Starts | Housing |
| MBA Purchase Index | Housing |
| Michigan Consumer Sentiment | Consumer Surveys |
| ISM Manufacturing PMI | Business Surveys |
| ISM Services Prices | Business Surveys |
| ZEW Economic Sentiment Index | Business Surveys |
| EIA Crude Oil Stocks Change | Energy |
| M2 Money Supply YoY | Misc |
| General Election | Misc |

The category display order starts with Holiday and ends with Misc.

**T4. Weeks**
- The default week is **Sun Oct 18 – Sat Oct 24, 2026**.
- Previous week is Oct 11–17, next is Oct 25–31, and ten weeks ahead is Dec 27 – Jan 2.
- The fetch window for Oct 18–24 is **from=2026-10-17, to=2026-10-25**.

**T5. Labels**

| Input | Output |
|---|---|
| Week label, within one month | `Oct 18 – 24, 2026` |
| Week label, across months | `Oct 25 – Nov 7, 2026` |
| Week label, across years | `Dec 27, 2026 – Jan 2, 2027` |
| Day tab for 2026-10-22 | `Thu 22` |
| Day header for 2026-10-22 | `Thursday, Oct 22, 2026` |
| Toronto offset on Oct 20 | `UTC−4` |
| Toronto offset on Nov 10 | `UTC−5` (daylight saving) |
| Countdown, 2 h 15 m | `2 hours 15 minutes` |
| Countdown, 61 s | `1 minute 1 second` |

**T6. Number formatting**

| Value | Unit | Shows |
|---|---|---|
| 3.7 | % | `3.7%` |
| 1234.5 | $ | `$1,234.5` |
| 1.4 | CHF | `1.4 CHF` |
| 0.44751 | none | `0.448` (3 decimals at most) |
| 2 | % | `2%` (no trailing zeros) |
| null | any | `—` |

Colours:
- Actual 2.1 is positive and Actual −0.3 is negative.
- Forecast is never coloured.
- 0 is not coloured.

## Phase 2: main view skeleton

**T7. Title line**
- "Economic Calendar" on the left.
- On the right: `Local: Toronto (UTC−4) ▾`, `|`, then ⚙.
- No Log out.

**T8. Week bar**
- `[‹] [Oct 18 – 24, 2026 | Sun 18 | Mon 19 | Tue 20 | Wed 21 | Thu 22 | Fri 23 | Sat 24] [›]`
- Thu 22 has the **Today** chip.
- The arrows are as tall as the bar.

**T9. Navigation**
- › shows Oct 25–31, and This Week becomes enabled.
- ‹ ‹ shows Oct 11–17.
- **This Week** returns to Oct 18–24 and is disabled there.
- Each move selects the week tab.

## Phase 3: events table

**T10. Default view counts (G20)**
- The week tab shows **220 events**.
- The day tabs show: Sun 18 **0**, Mon 19 **3**, Tue 20 **49**, Wed 21 **61**, Thu 22 **58**, Fri 23 **48**, Sat 24 **1**.
- Red dots appear on **Tue, Wed, Thu, Fri** only.
- (Mon 19's 3 events are Oct 20 00:00 UTC releases shown in Toronto time.)

**T11. Folding**
- On the current week, **Mon, Tue and Wed** start folded, and **Thu 22** (today) and **Fri 23** start expanded.
- Days with no events (Sun 18) have no row.
- Next week starts fully expanded.
- Clicking a day row toggles it, and so do ←/→.

**T12. Day rows**
- The header reads `▼ Thursday, Oct 22, 2026 [Today]`.
- `58 events` is right-aligned, ending 8px left of the Impact column's right edge.
- The day row is one full-width bar.

**T13. Event rows**
- Time is `HH:mm` in Toronto time.
- Holidays show `All day` and an italic name.
- Released or past events show their time in the muted colour.
- Impact shows three bars plus High/Med/Low.
- Flags are round, 16px.

## Phase 4: filters

**T14. Filter logic (G20, Oct 18–24)**

| Filter | Rows |
|---|---|
| All (default) | 220 |
| Entire world | 361 |
| Impact = High only | 11 |
| Search "inflation" (case-insensitive) | 19 |
| Entire world + Categories = Holiday only | 11 holidays |

**T15. Option counts (G20, Oct 18–24)**
- Impact: High **11**, Medium **69**, Low **140**.
- Categories:

  | Category | Count |
  |---|---|
  | Growth | 31 |
  | Inflation | 37 |
  | Employment | 11 |
  | Central Bank | 14 |
  | Speeches | 14 |
  | Bonds | 21 |
  | Housing | 20 |
  | Consumer Surveys | 9 |
  | Business Surveys | 37 |
  | Energy | 13 |
  | Misc | 13 |

- A menu's counts ignore that same filter but respect all the others.

**T16. Countries dropdown**
- Items: Entire world, G20, G7, Eurozone, Majors, separator, *(custom groups, separator)*, Choose countries…, Edit groups….
- The default shows "Countries **G20**".
- Picking G7 shows only CA, FR, DE, IT, JP, GB and US rows.

**T17. Menus**
- Impact and Categories stay open while toggling.
- "Clear" then ticking one option makes the button read that option's name.
- Two options read `2 selected`. None reads `None`, and the empty-state message appears.
- Categories lists Holiday first, then a separator.

**T18. Reset filters**
- Hidden at the defaults.
- Appears after any change: countries, impact, categories or search.
- Clicking it restores G20, All, All and an empty search. It doesn't change the week or the selected day.

## Phase 5: dialogs

**T19. Choose countries**
- Opening it from G20 pre-ticks the **20** G20 members, and only regions with ticks are expanded.
- North America shows `2 of 2` ticked, and partly ticked regions show the dash state.

**T20. Choose countries actions**
- **Clear** unticks everything and disables Apply.
- Searching "nether" leaves only Netherlands.
- Ticking the North America region ticks Canada and the United States.
- **Apply** with 3 countries makes the dropdown read `3 countries`, and the table shows only those.
- With one country (Japan) it reads `Japan`.

**T21. Save as group…**
- Opens Settings → Country groups → New group with the ticked countries.
- Saving "Asia watch" with JP and KR adds it under a separator in the Countries dropdown, and choosing it filters to JP and KR.

**T22. Group editor validation**
- An empty name shows "Give the group a name."
- A name of 41 characters or more is rejected.
- The name "g7" shows “G7” is a built-in group name.
- No countries shows "Pick at least one country."
- Duplicating G20 opens the editor with the name `G20 (copy)`.

**T23. Delete confirmation**
- The title is "Delete group" and **Cancel** is focused.
- Esc or Cancel keeps the group, and Enter doesn't delete it.
- Delete removes it from the list and from the dropdown, and Settings stays open.

## Phase 6: alerts

**T24. Defaults**
- Alerts are **on**, the rule is countries **US**, impact **High**, categories empty (any), and the lead time is **10 minutes**.
- The summary reads: "On: alerts go off 10 minutes before upcoming High-impact events in United States, in any category."

**T25. Default sync**
- With the fixed clock, **18** events are armed, all US and High impact.
- The first ones are Durable Goods Orders MoM (2026-10-27 12:30 UTC), Fed Interest Rate Decision (10-28 18:00) and Fed Press Conference (10-28 18:30).
- None fall in Oct 18–24.
- Next week shows **7** yellow bells.

**T26. Rule semantics**
- Countries US + GB arms GB high-impact events too.
- Categories = Employment only arms only employment releases.
- Clearing all countries means **any country**.
- Adding Low impact arms more events.
- Duplicates, holidays and past events never arm.

**T27. Turning off**
- All `armed` entries are removed and every bell disappears.
- Triggered and acknowledged entries stay, and come back when alerts are turned on again.

**T28. Firing**
- An armed event 8 minutes ahead with a 10-minute lead fires **immediately**.
- The alarm shows `Report alert`, the event, `Scheduled …`, and a live countdown.
- Esc doesn't close it. **Acknowledge** closes it.
- The bell turns **grey** (`faint`).
- Firing twice is impossible.

**T29. Bells**
- With alerts off there are no bells.
- With alerts on, armed bells are yellow and triggered or acknowledged bells are grey. Other events have no bell.
- Clicking any bell opens Settings → Alerts and changes no state.

**T30. Clear triggered alerts, lead time and persistence**
- **Clear triggered alerts** appears only when Triggered > 0. Its confirmation has Cancel focused.
- Confirming removes only the grey (acknowledged) entries. Waiting alerts stay.
- An acknowledged entry older than 30 days is pruned when saving.
- Lead-time validation:

  | Input | Result |
  |---|---|
  | "abc" | Enter a whole number of 0 or more. |
  | 721 hours | That's more than 30 days. Use at most 720 hours. |
  | 0 | accepted: "at the time of" |

- The settings survive a restart.

## Phase 7: refresh and offline

**T31. Refresh**
- A refresh fetches every 5 minutes.
- ⟳ fetches straight away, spins while fetching, and is disabled for 10 seconds afterwards; extra clicks are ignored.
- The tooltip reads `Refresh · last updated HH:mm`.

**T32. Release polling**
- With an event scheduled 1 minute ahead, a fetch happens about 60 seconds after its time.
- An event that gets an actual changes to released, and its time greys.

**T33. Offline copy**
- After a successful load the response is saved. At most 4 windows are kept.
- When the data source fails, here's what happens:

  | Situation | Behaviour |
  |---|---|
  | First run, no saved copy | Warning "Couldn't reach the data service. Retrying automatically" and the empty state "Can't load these dates right now." |
  | Live data was loaded this session | Rows stay. Warning "Update failed at HH:mm; showing data from HH:mm. Retrying automatically" |
  | Restart while offline | The saved copy shows. Warning "Can't reach the data service. Showing data saved Oct 22, HH:mm. Retrying automatically" |
  | Offline, week without a full saved copy | Can't-load state, with **no partial week** |

- When the source comes back, data returns to live and the warning clears.

**T34. Week change.** Moving to a week that isn't loaded fetches it. A saved copy covering it shows straight away first.

**T35. No other network traffic.** During a full session, the only HTTP requests are calendar requests (§4).

## Phase 8: theme and polish

**T36. Dark/light**
- Display → Light switches every colour per the §11 table.
- Blue/pink values are `#add8e6` / `#ffc0cb` in dark and `#1f6fae` / `#c2185b` in light.
- If the host owns the theme, the Appearance section is hidden.

**T37. Fonts and assets**
- All text renders in Inter (400, 500, 600) loaded from the bundled TTFs.
- Flags come from bundled PNGs, and icons from `icons.json` paths.

**T38. Visual match.** Side by side with each image in `screenshots/` at the same size, layout, spacing, colours and wording match. Small native rendering differences are acceptable.
