# Economic Calendar: data architecture (server + JavaFX client)

**For:** the Java developer building the JavaFX Economic Calendar.
**Hosting:** to run this on Google App Engine, see `DEPLOY-APP-ENGINE.md`.
**Status:** agreed design. Where this document differs from `HANDOFF.md` §4 (data source) and §9 (refresh and offline), **this document takes precedence**. Everything else in `HANDOFF.md` still applies.

---

## 1. The problem

The calendar data comes from one Finnhub endpoint, and **all of our clients share one API key**. If every client called Finnhub directly:
- the key would ship inside every client, where anyone could extract it
- Finnhub's rate limit would be hit as soon as enough clients were open
- every client would download the same data separately

## 2. The solution in one picture

```
                    Finnhub  (one API key, held only by our server)
                       ▲
                       │  our server's schedule, ~400–500 calls/day in total
                       │  (the same whether we have 10 clients or 10,000)
              ┌────────┴─────────┐
              │   Calendar       │  keeps ONE copy of the data:
              │   server (ours)  │  1 month back → 2 months ahead
              └────────┬─────────┘  versioned, compressed, cached
                       │
          GET /calendar│  "has anything changed since version N?"
                       │  usually: 304 Not Modified (tiny, no data)
        ┌──────────────┼──────────────┐
   JavaFX client   JavaFX client   JavaFX client …
   (replaces its local copy only when the version changes;
    week navigation, filters and search never call anything)
```

**The rules:**
1. **Only the server talks to Finnhub.** Clients never see the API key.
2. **The server does all the timing:** regular refreshes, plus a quick refresh just after each scheduled release, so new actual values appear fast.
3. **Clients ask "has it changed?" once a minute.** Almost always the answer is "no" (HTTP 304, a few hundred bytes).
4. **When the data changes, clients download the whole dataset** (about 200 KB compressed) and replace their copy. No merging on the client.
5. **Everything the user does** (changing week, filters, search, settings) works on the local copy, with **no network call**.

---

## 3. The calendar server

### 3.1 What it holds

| Item | Description |
|---|---|
| `dataset` | Every event from **today − 1 month** to **today + 2 months**, in Finnhub's own format (fields below). |
| `version` | A number that goes up **only when the data actually changes** (detected by hashing the content). |
| `gzippedJson` | The dataset serialised and gzip-compressed **once per version**, so serving thousands of clients costs almost nothing. |
| `updatedAt` | When the data last changed. |

Keep it as one **immutable snapshot** behind an `AtomicReference`. Each refresh builds a new snapshot and swaps it in, so readers never see half-updated data. Also **save the snapshot to disk**, so a server restart can serve immediately.

An event looks like this (Finnhub's format, unchanged; `time` is UTC):

```json
{"actual":3.0,"country":"CN","estimate":3.0,"event":"Loan Prime Rate 1Y","impact":"medium","prev":3.0,"time":"2026-10-20 01:00:00","unit":"%"}
```

### 3.2 When the server calls Finnhub

There are **three triggers**. They're all on the server; clients never cause a Finnhub call.

| Trigger | What it fetches | Why |
|---|---|---|
| **Full refresh, every 30 minutes** (and at startup) | The whole window: −1 month … +2 months | Picks up new events, schedule changes and revised forecasts across the whole period. Older and future weeks rarely change, so 30 minutes is plenty. |
| **Today refresh, every 5 minutes** | Yesterday … tomorrow (small and fast) | Keeps the current days fresh. The window is ±1 day because times are UTC and clients are in different time zones. |
| **Release refresh, about 60 seconds after each scheduled release** | Yesterday … tomorrow | New actual values appear about a minute after a release, not up to 5 minutes later. |

**Which releases trigger the release refresh?** Every event in the **complete dataset**, never filtered by any user's settings, because one call serves every client. Include an event when it:
- is scheduled in the future
- has no `actual` yet
- normally publishes a number (it has an `estimate` or `prev`)
- is not a holiday: midnight (`00:00:00`), no values, and not an election, plenum, meeting, budget or referendum

**Coalescing:** releases in the same minute share one call, and the server never runs release refreshes more than **once per minute**.

### 3.3 Pseudocode

```java
// ---- Scheduling (ScheduledExecutorService) ----
onStartup() {
    snapshot = loadFromDisk();                 // serve immediately if present
    fullRefresh();
    every(30, MINUTES, this::fullRefresh);
    every(5,  MINUTES, this::todayRefresh);
}

void fullRefresh() {
    LocalDate from = today().minusMonths(1), to = today().plusMonths(2);
    List<Event> events = fetchFinnhub(from, to);      // split per month if Finnhub caps a response
    publish(events);                                  // replaces everything
}

void todayRefresh() {
    LocalDate from = today().minusDays(1), to = today().plusDays(1);
    List<Event> fresh = fetchFinnhub(from, to);
    // Replace only those days: drop old events dated from..to (by UTC date), add the fresh ones
    publish(merge(snapshot.events(), fresh, from, to));
}

void scheduleReleaseRefreshes() {                     // call after every publish()
    cancelPendingReleaseRefreshes();
    snapshot.events().stream()
        .filter(e -> e.time().isAfter(now()) && e.actual() == null && e.expectsValue() && !e.isHoliday())
        .map(e -> e.time().plusSeconds(60).truncatedTo(MINUTES))   // same-minute releases share one call
        .distinct()
        .forEach(t -> scheduleAt(t, this::todayRefresh));          // keep at most one per minute
}

void publish(List<Event> events) {
    String hash = sha256(canonicalJson(events));
    if (hash.equals(snapshot.hash())) return;           // nothing changed: version stays the same
    snapshot = new Snapshot(snapshot.version() + 1, hash, events,
                            gzip(json(events)), Instant.now());
    saveToDisk(snapshot);
    scheduleReleaseRefreshes();
}
```

### 3.4 Calling Finnhub

```
GET https://finnhub.io/api/v1/calendar/economic?from=YYYY-MM-DD&to=YYYY-MM-DD
Header: X-Finnhub-Token: <key>       (the key comes from server config or a secret store, never from code)
```

- **On any error:** keep serving the last good snapshot. Log the error and don't bump the version.
- **On 429 (rate limit):** back off by 1 min, 2, 4, 8 (max 15), then resume the normal schedule.
- **Check before building:** make one call for the full 3-month window and confirm Finnhub returns it **complete**. If it truncates long ranges, fetch month by month and combine.

### 3.5 The endpoint for clients

```
GET /calendar
Request headers:
    Authorization: Bearer <client app token>     (use the host app's existing licence or login)
    If-None-Match: "<version the client already has>"   (optional)
    Accept-Encoding: gzip

Responses:
    304 Not Modified        – the client already has the latest version (no body)
    200 OK                  – the full dataset
        Content-Encoding: gzip
        ETag: "<version>"
        Cache-Control: no-cache
        Body: {
          "version": 1234,
          "from": "2026-09-24", "to": "2026-12-24",        // the dataset's date window
          "updatedAt": "2026-10-24T13:31:05Z",
          "economicCalendar": [ ...events in Finnhub format... ]
        }
    401 / 403               – bad or missing app token
    429                     – the client is polling too fast (more than ~1 request per 10 s)
    503                     – the server has no data yet (startup with nothing on disk)
```

```java
// Pseudocode for the handler
Response getCalendar(Request req) {
    authenticate(req);                       // 401/403 if invalid
    rateLimit(req.clientId());               // 429 if abused
    Snapshot s = snapshot;                   // read once (immutable)
    if (s == null) return status(503);
    if (("\"" + s.version() + "\"").equals(req.header("If-None-Match"))) return status(304);
    return ok(s.gzippedJson())
        .header("Content-Encoding", "gzip")
        .header("ETag", "\"" + s.version() + "\"")
        .header("Cache-Control", "no-cache");
}
```

---

## 4. The JavaFX client

### 4.1 Behaviour

| When | What the client does |
|---|---|
| **App opens** | Shows the dataset saved on disk straight away (if any), then polls. |
| **Every 60 seconds** | Polls (`If-None-Match` = its version). 304: do nothing. 200: replace everything. |
| **User clicks ⟳ Refresh** | Polls now, then disables the button for 10 seconds. |
| **User changes week (‹ › This Week)** | No call. Shows that week from the local dataset. |
| **User changes filters, search, settings** | No call. Everything is filtered locally. |
| **Poll fails** | Keeps showing the current data, with a warning (wording below). Tries again at the next poll. |

The client **never** schedules release polls, merges data or fetches individual weeks. The server already did that work.

### 4.2 Pseudocode

```java
final class ServerDataSource {
    private final HttpClient http = HttpClient.newHttpClient();
    private volatile String etag;                       // version we hold, e.g. "\"1234\""

    /** New dataset, or empty when unchanged (304). Runs on a background thread. */
    Optional<Snapshot> poll() throws IOException, InterruptedException {
        HttpRequest.Builder req = HttpRequest.newBuilder(serverUri.resolve("/calendar"))
            .header("Authorization", "Bearer " + host.appToken())
            .header("Accept-Encoding", "gzip")
            .timeout(Duration.ofSeconds(20));
        if (etag != null) req.header("If-None-Match", etag);

        HttpResponse<InputStream> res = http.send(req.build(), BodyHandlers.ofInputStream());
        if (res.statusCode() == 304) return Optional.empty();
        if (res.statusCode() != 200) throw new IOException(messageFor(res.statusCode()));

        boolean gz = res.headers().firstValue("Content-Encoding").orElse("").contains("gzip");
        try (InputStream in = gz ? new GZIPInputStream(res.body()) : res.body()) {   // HttpClient doesn't unzip
            Snapshot s = json.read(in, Snapshot.class);
            etag = res.headers().firstValue("ETag").orElse(null);
            return Optional.of(s);
        }
    }
}

// In the calendar module
void start() {
    loadSavedSnapshot().ifPresent(this::apply);                 // instant start, works offline
    scheduler.scheduleWithFixedDelay(this::pollSafely, 0, 60, SECONDS);
}

void pollSafely() {
    try {
        dataSource.poll().ifPresent(s -> {
            saveSnapshotToDisk(s);
            Platform.runLater(() -> apply(s));                 // replace dataset, re-render, re-sync alerts
        });
        Platform.runLater(() -> setStatus(OK));
    } catch (Exception e) {
        Platform.runLater(() -> setStatus(OFFLINE, e));        // keep current data, show warning
    }
}

void apply(Snapshot s) {
    events = EventNormalizer.normalize(s.economicCalendar());   // ids, holidays, categories (HANDOFF §5)
    window = new DateRange(s.from(), s.to());                   // ‹ › stop at these dates
    lastUpdated = s.updatedAt();
    alerts.sync(events);                                        // arms alerts for the whole 2 months ahead
    refreshView();
}
```

### 4.3 Week navigation limits

The dataset covers about **−1 month to +2 months**:
- **‹** is disabled on the first week that's inside the window, and **›** on the last.
- Their tooltips say which dates are available: *"Calendar data is available from Sep 24 to Dec 24"*.
- The user can never land on an empty, unexplained week.

### 4.4 Wording (never name the data provider)

| Situation | Message |
|---|---|
| Normal (⟳ tooltip) | Refresh · last updated 13:31 |
| Poll failed, showing saved data | Can't reach the data service. Showing data from Oct 24, 13:31. Retrying automatically |
| First start, no saved data, server unreachable | Can't load the calendar right now. Retrying automatically |
| Server says 401/403 | The data service rejected this app's access. Contact support |

---

## 5. Why this is efficient

| | Old way (each client calls Finnhub) | This design |
|---|---|---|
| Finnhub calls | Grows with every client | **~400–500 a day in total**, fixed |
| API key exposure | In every client | **Server only** |
| Client traffic per hour | — | 60 tiny 304s, plus a full download (~200 KB) only when data changed |
| Time for a new actual to appear | Up to 5 min | **~1–2 min** (server refresh at +60 s, client poll within 60 s) |
| Changing weeks or filters | Network calls | **None** (local) |
| Alerts for future weeks | Only weeks the user had browsed to | **All 2 months ahead**, immediately |
| Offline | Per-week copies | **One saved snapshot** |

**Possible later improvement:** the server pushes a "new version" notice to clients over a lasting connection (Server-Sent Events or WebSocket), and the client polls immediately. Updates then arrive within seconds, and the idle 60-second polls stop. It isn't needed to launch.

---

## 6. Settings to make configurable (server)

| Setting | Default |
|---|---|
| Window | 1 month back, 2 months ahead |
| Full refresh interval | 30 min |
| Today refresh interval | 5 min |
| Release refresh delay | 60 s after the scheduled time |
| Minimum gap between release refreshes | 1 min |
| 429 back-off | 1, 2, 4, 8 min (max 15) |
| Client rate limit | ~1 request per 10 s per client |

## 7. Acceptance checks

**Server**
- [ ] Starting with nothing on disk returns 503 until the first full refresh, then 200.
- [ ] A second request with the returned ETag gets **304** and no body.
- [ ] A refresh that returns identical data **does not** change the version. A changed actual value **does**.
- [ ] The today refresh replaces only yesterday–tomorrow, and everything else in the window is untouched.
- [ ] Release refreshes fire about 60 s after release times. Three releases at 08:30 cause **one** call.
- [ ] During a Finnhub outage the last snapshot keeps being served, and a 429 triggers back-off.
- [ ] Load test: 1,000 simulated clients polling every 60 s cause **zero** extra Finnhub calls.
- [ ] The API key appears nowhere in responses, logs or client code.

**Client**
- [ ] The app opens with the saved snapshot while offline and shows the offline warning.
- [ ] A 304 changes nothing, and a 200 replaces the dataset and re-syncs alerts.
- [ ] ‹ › stop at the window edges with the "available from … to …" tooltip.
- [ ] Changing weeks, filters or search makes **no** network request.
- [ ] Refresh is disabled for 10 s after a click.

## 8. To confirm before building

1. Does Finnhub return the full 3-month window in one call, or does it need splitting by month?
2. How clients authenticate to the server: reuse the host app's licence or login token.
3. Where the server runs (existing infrastructure?) and where the API key is stored (environment variable or secret manager).
