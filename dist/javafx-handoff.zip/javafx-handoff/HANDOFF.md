# Economic Calendar: JavaFX port

> **Before any code, run `SETUP.md`.** It confirms with the developer which of their own components replace the standard JavaFX controls named here, the address of our calendar server, and which host services to reuse, and records the answers in `econocalendar-integration.md`. **The client's only data source is our calendar server on Google App Engine** (`DATA-SERVER.md`, `DEPLOY-APP-ENGINE.md`). It never calls the data provider.

This document tells you (Claude, working with a Java developer) how to rebuild the **Economic Calendar** as a **JavaFX module inside an existing JavaFX application**. A finished web prototype exists. This document describes what to build. The prototype's source in `reference/` is the source of truth for exact details: wording, rules, colours and edge cases. Where the two disagree, follow this document and flag the difference.

**Order of precedence:** `econocalendar-integration.md` (the confirmed setup answers), then `DATA-SERVER.md` for data and refresh, then this document, then `reference/`. Where this document names a standard JavaFX control, read it as **the role**, and use the class the integration file maps to that role. The described behaviour still applies, except where the integration file records a gap.

---

## 0. Start here

### The package

| Path | What it is |
|---|---|
| `SETUP.md` | Phase 0: the setup questionnaire (components, server endpoint, host services). Run it first. |
| `HANDOFF.md` | This document. Read it all before writing code. |
| `DATA-SERVER.md` | How data flows: our server is the only caller of the data provider, and clients poll it. |
| `DEPLOY-APP-ENGINE.md` | How that server runs on Google App Engine. |
| `reference/` | The final web prototype (HTML/CSS/JS): `js/core/` is the pure logic, `js/ui/` the components, `js/app.js` the wiring. **Reference only. Never port it line by line or embed a WebView.** Use it to look up exact rules and wording. The key files are listed in §16. |
| `screenshots/` | How every screen and state looks (dark theme unless named). Match these. |
| `assets/fonts/` | Inter Regular, Medium and SemiBold as **TTF** (JavaFX can't load web fonts), plus its licence. |
| `assets/flags/` | 271 round country flags as 64×64 PNG (lower-case ISO codes, e.g. `us.png`), plus their licence. |
| `assets/icons/` | Icons as SVG, plus `icons.json`, which holds each icon as SVG path data ready for `SVGPath`. |
| `test-data/sample-calendar.json` | A real API response (Oct 2026) to use as a fixture in tests and offline development. |
| `tests.md` | Acceptance checks. The Java version must pass all of them. |

### Opening prompt (paste into Claude Code at the root of the host app)

> You're adding an **Economic Calendar** feature to this existing JavaFX application. Read `javafx-handoff/SETUP.md`, `HANDOFF.md`, `DATA-SERVER.md` and `tests.md` fully, and look at every image in `javafx-handoff/screenshots/`. Use `javafx-handoff/reference/` (a web prototype) only to look up exact rules and wording. Don't port it line by line and don't use a WebView.
>
> Rules:
> - Use this app's own components wherever it has them, and standard JavaFX for the rest. Don't add new libraries or dependencies without asking.
> - The only network call is to our calendar server (`DATA-SERVER.md` §3.5). Fonts, flags and icons are bundled resources unless setup decides otherwise.
> - Build it as a self-contained module (§3) that the host app opens.
> - Work in the phases in §15. Finish each phase, run its checks from `tests.md`, and stop for review before the next.
>
> Start with phase 0 (`SETUP.md`): scan this codebase, then send me **one** questionnaire with your proposed answer for every item: placement, the component for each role, the calendar server's address and auth, host services, and anything else to include or leave out. After I reply, write `econocalendar-integration.md` and show it for one confirmation. Write no other code before I confirm it.

---

## 1. What the app is

A weekly calendar of economic releases (CPI, payrolls, rate decisions, holidays…) for traders. It shows one week (Sunday to Saturday) at a time, in a table grouped by day. Users filter by country, impact and category, search by name, and get an alarm a set time before the releases they care about. Data comes from our calendar server, which refreshes it on a schedule and about one minute after each scheduled release. The app checks the server for a new version every minute, so actual values appear promptly.

Screens (see `screenshots/`):
- **Main view** (`01`, `03`): title line, week bar, filter line, events table.
- **Choose countries** dialog (`08`).
- **Settings** dialog with three tabs: Country groups (`09`, `10`), Alerts (`11`, `12`), Display (`13`).
- **Confirmation** alert (`14`).
- **Alarm** dialog (`15`).

---

## 2. Decisions already made

- **Integrated, not standalone:** a module inside the existing JavaFX app (§3).
- **No login or logout.** The prototype's password screen and its encrypted key file were web-demo only. Ignore `index.html`'s `#login` and anything about "Prototype Portal", `auth`, `vault` or `credentials`.
- **The host app's own components** replace the standard JavaFX controls named in §7 and §8, as mapped in `econocalendar-integration.md` (`SETUP.md`). Standard JavaFX fills any role the host has no component for. No new UI libraries.
- **Only one network call:** `GET /calendar` on our calendar server on Google App Engine (§4). Everything else is bundled.
- **Never name the data provider in the UI.** Messages say "the data service".
- **No data-provider API key in the client.** It lives only on the server (Secret Manager, `DEPLOY-APP-ENGINE.md`). The client authenticates to our server with the host app's own token.
- **The phone/mobile layout isn't needed.** Ignore the prototype's `@media (max-width: 560px)` CSS.

---

## 3. Integration architecture

Build a self-contained package, e.g. `…econcalendar`, with one public entry point the host app opens: a tab, a window or a docked panel, whatever fits the host.

```java
// Public API (shape, not exact names)
public final class EconomicCalendar {
    public EconomicCalendar(CalendarHost host);   // host supplies services below
    public Node getView();                         // the whole calendar UI (a BorderPane)
    public void start();  public void stop();      // begin/stop data refresh + timers
    public IntegerProperty triggeredAlertCountProperty(); // host can badge its tab/title "(2)"
}

public interface CalendarHost {
    Window owner();                                // owner for dialogs
    CalendarDataSource dataSource();               // §4 (ServerDataSource: our server, host token)
    SettingsStore settings();                      // §10 persistence (default: java.util.prefs)
    default ZoneId systemZone() { return ZoneId.systemDefault(); }
    default ThemeMode hostTheme() { return null; } // if the host owns dark/light, return it (§11)
}
```

Suggested internal structure (one class per concern):

| Layer | Classes | Prototype equivalent |
|---|---|---|
| Data | `CalendarDataSource`, `ServerDataSource`, `FixtureDataSource` (tests), `SnapshotCache` (offline copy) | none: the prototype calls the provider per week; see `DATA-SERVER.md` §4 |
| Model | `EconEvent` (record), `EventNormalizer`, `Category` rules, `Impact` enum | `js/core/events.js` |
| Time | `CalendarTime` (week maths, labels, zones list) | `js/core/time.js` |
| Countries | `Countries` (names, regions), `CountryGroups` (built-in + custom) | `js/core/countries.js`, `js/core/groups.js`, `js/data/country-groups.js` |
| Filtering | `FilterState`, `Filters` (pure functions + counts) | `js/core/filters.js` |
| Alerts | `AlertEngine` (rule, states, sync, check, persistence) | `js/core/alerts.js` |
| UI | `CalendarView`, `WeekBar`, `FilterBar`, `EventsTable`, `ChooseCountriesDialog`, `CountryTree`, `SettingsDialog`, `AlarmDialog`, `Confirm` | `js/app.js`, `js/ui/*.js` |

The UI classes build on the components in the integration file's component map. Create them in one place (for example a small `Controls` factory), so a mapping change touches one class.

Threading: poll on a background thread (the executor named in the integration file, or a `ScheduledExecutorService`). Update the model and UI on the FX thread (`Platform.runLater`). Use one `Timeline` for the 15-second clock tick (alerts, greyed times) and one scheduled task for the 60-second poll (§9). `stop()` must cancel both.

Keep the model and engine classes free of JavaFX imports where practical, so they're unit-testable (`tests.md`).

---

## 4. Data source: our calendar server

The client never calls the data provider and holds no provider API key. Its one data source is **our calendar server on Google App Engine**, which keeps one shared, versioned copy of the data (`DATA-SERVER.md` §3, `DEPLOY-APP-ENGINE.md`). The base URL and the auth token come from `econocalendar-integration.md`.

### 4.1 Endpoint (the only network call)

```
GET <server base URL>/calendar
Authorization: Bearer <host app token>
If-None-Match: "<version the client holds>"     (omit when it holds none)
Accept-Encoding: gzip
```

| Response | Meaning |
|---|---|
| **304** Not Modified | The client already has the latest version. Nothing to do. |
| **200** OK | The full dataset, gzip-compressed, with `ETag: "<version>"`. Java's `HttpClient` doesn't unzip, so wrap the body in a `GZIPInputStream`. |
| 401 / 403 | The app token is missing, wrong or expired. |
| 429 | Polling too fast. |
| 503 | The server has no data yet. |

The 200 body:

```json
{"version":1234,"from":"2026-09-24","to":"2026-12-24","updatedAt":"2026-10-24T13:31:05Z",
 "economicCalendar":[ {"actual":3.0,"country":"CN","estimate":3.0,"event":"Loan Prime Rate 1Y","impact":"medium","prev":3.0,"time":"2026-10-20 01:00:00","unit":"%"}, ... ]}
```

- `from` / `to` is the dataset's window: about **1 month back to 2 months ahead**. Week navigation stops at it (§9).
- `updatedAt` is when the data last changed. It's what "last updated" shows.
- Each event keeps the provider's own format:
  - `time` is **UTC**, `"YYYY-MM-DD HH:MM:SS"`.
  - `actual`, `estimate` and `prev` are numbers or `null`.
  - `impact` is `"high"`, `"medium"` or `"low"`. Anything else counts as `"low"`.
  - `country` is an ISO-2 code (plus `EU` for the euro area aggregate).
  - `unit` may be `""`, `"%"`, a currency symbol (`$ € £ ¥`) or a code (`CHF`, `PHP`).

**Weeks are cut locally.** The week shown (Sunday to Saturday in the display zone) holds the events whose UTC time falls inside it. Changing weeks, filters or search never makes a request.

**Error messages** never name the provider:

| Condition | Message |
|---|---|
| Network failure or timeout | couldn't reach the data service |
| 401 / 403 | the data service rejected this app's access. Contact support |
| 429 | too many requests, retrying shortly |
| 503 | the data service has no data yet |
| Other non-2xx | the data service returned an error (NNN) |
| Bad JSON | the data service sent an unreadable response |
| No `economicCalendar` array | the data service sent an unexpected response |

### 4.2 Data source implementations

All three implement `CalendarDataSource` (`poll()` returns a new snapshot, or nothing when unchanged):

| Class | Use |
|---|---|
| `ServerDataSource` | Production. Polls our server as above. Pseudocode: `DATA-SERVER.md` §4.2. |
| `FixtureDataSource` | Tests and offline development. Wraps `test-data/sample-calendar.json` as version 1, with `from = 2026-09-22`, `to = 2026-12-22` (one month back and two ahead of the test clock in `tests.md`) and `updatedAt = 2026-10-22T15:55:00Z`. |
| Local stub server | Until our App Engine server is deployed (if setup chose it): a few lines serving the same snapshot at `/calendar` with ETag/304, so `ServerDataSource` can be exercised for real. |

---

## 5. Data model and rules

### 5.1 Normalising events (`reference/js/core/events.js → normalize`)

For each item with a string `time` and `event` and a parseable time:
- `ts` is the epoch millis of `time` read as UTC.
- `type` is the **category** (§5.3).
- `holiday` is true when `type == "Holiday"`.
- `expectsValue` is true when any of `estimate`, `prev` or `actual` is non-null.
- `name` is the country's display name (§5.5).
- **`id` (stable):** `country + "|" + time + "|" + event`. If the exact same triple appears again, append `#1`, `#2`… so ids stay unique. Alert state is keyed by this id, so it survives reloads and re-sorting.
- **Duplicates:** after sorting by `ts`, a repeat of the same `country + event + UTC date` gets `dup = true`. Duplicate rows are **always hidden**, and they never alert.
- **Sort order:** by `ts`, ascending.

### 5.2 Holiday detection

An event is a holiday when **all** of these hold:
- `time` ends with `00:00:00`
- `actual`, `estimate` and `prev` are all null
- the name doesn't match `/election|plenum|meeting|budget|referendum/i`

Holidays belong to their **listed date** (the date part of `time`), not a zone-shifted date. Their Time cell shows **All day**, and the name is shown in italics.

### 5.3 Categories (keyword rules)

The API has no category field. The category comes from the event name: the **first matching rule wins**, and otherwise it's `Misc`. Holidays (§5.2) are checked first. **Copy the rules exactly**, in order, from `TYPE_RULES` in `reference/js/core/events.js`. The regexes are case-insensitive and port directly to `java.util.regex.Pattern` with `CASE_INSENSITIVE`.

Display order (used in menus and the Alerts tab):

`Holiday, Growth, Inflation, Employment, Central Bank, Speeches, Bonds, Housing, Consumer Surveys, Business Surveys, Energy, Misc`

These rule orderings matter, and `tests.md` checks them:
- "BoE Gov Bailey Speech" is **Speeches**, not Central Bank.
- "Atlanta Fed GDPNow" is **Growth**.
- "RBA Trimmed Mean CPI" is **Inflation**.
- "Retail Price Index" is **Inflation**, not Growth.
- "Housing Price Index" is **Housing**.
- "ISM Services Prices" is **Business Surveys**.
- "BoJ Quarterly Outlook Report" is **Central Bank**.

### 5.4 Release state (internal, no column)

There's no Status column, but each event has a state that drives styling and alerts:
- **holiday:** a holiday.
- **released:** `actual != null`. This always wins over the clock.
- **upcoming:** `ts > now`.
- **awaiting:** the time has passed with no actual, and `expectsValue` is true.
- **past:** the time has passed and `expectsValue` is false (speeches, meetings).

Rows that are **released** or **past** show their Time in the muted colour.

### 5.5 Countries, regions and groups

- Country names and the region lists are in `reference/js/data/country-groups.js` (`COUNTRY_REGIONS`) and `reference/js/core/countries.js`.
- The region display order follows `COUNTRY_REGIONS`, with `Other` last.
- Codes without a known name show the code itself.
- `EU` shows as "Euro Area".
- `WW` (world) has no flag, so it uses the `globe` icon.

**Built-in groups**, which can't be edited:

| id | Name | Description | Members |
|---|---|---|---|
| g20 | G20 | Top 20 economies | AR AU BR CA CN FR DE IN ID IT JP KR MX RU SA ZA TR GB US EU |
| g7 | G7 | Group of Seven | CA FR DE IT JP GB US |
| eurozone | Eurozone | Euro area members + aggregate | AT BE BG HR CY EE FI FR DE GR IE IT LV LT LU MT NL PT SK SI ES EU |
| majors | Majors | Major currency economies | US EU GB JP CA AU NZ CH |

**Custom groups** are user-made and saved. The rules are in `reference/js/core/groups.js`:

| Rule | Message |
|---|---|
| Name required | Give the group a name. |
| Name ≤ 40 characters | Keep the name to 40 characters or fewer. |
| Name unique (case-insensitive), including built-ins | “G20” is a built-in group name. / You already have a group called “X”. |
| At least one country | Pick at least one country. |

### 5.6 Filtering (`reference/js/core/filters.js`)

Filters combine with AND. Each multi-select filter uses **`null` for "All"** and an explicit set otherwise, so "All" and "Clear" (an empty set) are different states:
- **Countries:** the union of the selected groups' members and the individually picked countries. Empty means all countries.
- **Impact:** a set of impact levels.
- **Categories:** a set of category names. Holiday is one of the categories.
- **Search:** a case-insensitive substring match on the event name.
- **Date:** the visible week, or the one selected day.
- **Duplicates:** always hidden.

**Option counts** in the Impact and Categories menus are computed with every *other* filter applied and that filter itself left out, so each count shows what ticking that option would give.

### 5.7 Number formatting and colours

Actual, Forecast and Previous are formatted as follows:
- `null` shows an em dash `—`, in the muted colour.
- Otherwise the number uses the locale's grouping, with at most 3 decimals, no trailing zeros, and `RoundingMode.HALF_UP` (Java's `DecimalFormat` defaults to HALF_EVEN, so set it):
  - unit `%` gives `3.7%`
  - a one-character currency symbol goes in front: `$1,234`
  - any other unit goes after a space: `1.4 CHF`
  - no unit gives the bare number.

**Actual** and **Previous** are coloured: positive numbers use `pos`, negative ones use `neg`, and 0 or null stay uncoloured. **Forecast** is never coloured. The colours come from Settings → Display (§8.4).

---

## 6. Time and weeks (`reference/js/core/time.js`)

- The **display zone** defaults to the saved "Default time zone" (initially **Local**, the system zone). The title-line dropdown changes it **for this session only**.
- An event's day is its date in the display zone. Holidays are the exception: they keep their listed date.
- **Weeks run Sunday to Saturday.** The default is the week containing today in the display zone. There are **no custom date ranges**: navigation is only previous week, next week and This Week.
- **Day rollover:** a 15-second clock tick checks whether "today" has changed. If the user was viewing the current week, the view moves to the new current week.
- **Zone list,** with separators between the groups: General (Local, UTC), Americas, Europe & Africa, Asia & Pacific. Copy `ZONES` from `time.js`. Labels look like:
  - `Local: Toronto (UTC−4)`: the last part of the system zone id, underscores turned into spaces, then the current offset
  - `UTC`
  - `New York (UTC−4)`

  Offsets use the Unicode minus `−`, as `UTC±H` or `UTC±H:MM`, computed for the current instant so daylight saving is right.
- **Label formats (en-US):**

  | Where | Format | Example |
  |---|---|---|
  | Day headers | weekday long, month short, day, year | `Thursday, Oct 22, 2026` |
  | Day tabs | weekday short + day | `Thu 22` |
  | Week box | see §7.2 | `Oct 18 – 24, 2026` |
  | Times | 24-hour `HH:mm` in the display zone | `08:30` |

- **Countdowns (alarm):**
  - `2 hours 15 minutes`, `4 minutes 32 seconds`, `1 day 3 hours`: the two largest units, with singular and plural forms
  - `Released` once the report is out
  - `due now` when the time has come but there's no value yet

---

## 7. Main view: layout and controls

The whole view sits on the page background, with a 16px left and right margin and 32px at the top. The font is **Inter** throughout (§12). Compare against `screenshots/01-main-dark.png`.

```
[invisible "Log out" line: omit in Java]
Economic Calendar                                          Local: Toronto (UTC−4) ▾  |  ⚙
                                                                            (36px gap)
[‹] [ Oct 18 – 24, 2026 | Sun 18 | Mon 19 | Tue 20 • | … | Fri 23 Today • | Sat 24 ] [›]
                                                                            (24px gap)
Countries G20 ▾  Impact All ▾  Categories All ▾  Reset filters      [This Week] [🔍 Search events] ⟳
                                                                            (14px gap)
┌ Time │ Country │ Impact │ Event │ Actual │ Forecast │ Previous │ Alert ┐
│ ▶ Monday, Oct 19, 2026                  3 events                       │
│ ▼ Friday, Oct 23, 2026  [Today]        48 events                       │
│ 01:00 │ 🇯🇵 Japan │ ▂▄▆ Low │ Coincident Index Final │ — │ — │ 120.6 │  │
```

### 7.1 Title line

An `HBox`: the title on the left, the time zone and settings on the right.

| Element | JavaFX | Details |
|---|---|---|
| "Economic Calendar" | `Label` | 20px, weight 600 |
| Time zone dropdown | `ChoiceBox<ZoneOption>` with `Separator` items between groups | Flat "plain text" look: no box, value in weight 600 at 12.5px, small ▾ triangle (`menu-arrow` icon). Text turns `accent-text` on hover. Session-only change (§6). |
| `|` | `Label` | `faint` colour |
| ⚙ Settings | `Button` with the `gear` icon graphic, transparent background | 28×28, icon in `muted`, `fg` on hover. Tooltip "Settings". Opens the Settings dialog on its first tab. |

The host app has its own way to quit or log out, so there's **no Log out**.

### 7.2 Week bar

`HBox`: **[‹ Button] [day tabs] [› Button]**, all 48px tall. See `screenshots/01` and `02`.

**‹ and ›**
- `Button`s 36px wide and the same height as the tab bar, with `chevron-left` / `chevron-right` icons (20px, stroke 2.5, `fg` colour).
- Normal button gradient, with hover and pressed states.
- Tooltips "Previous week" / "Next week". Each moves the view one week.
- They're disabled at the edges of the server's data window, with the tooltip `Calendar data is available from Sep 22 to Dec 22` (§9).

**Day tabs**
- Eight `ToggleButton`s in one `ToggleGroup`, inside an `HBox`, each set to grow equally (`HBox.setHgrow(ALWAYS)`, `maxWidth = MAX_VALUE`). They're joined into one segmented bar, using Modena's `left-pill` / `center-pill` / `right-pill` style classes or equivalent CSS.
- Each tab's graphic is a two-line `VBox`:
  - **Line 1:** the label in 13px weight 600. On today's tab add the **Today** chip (a `Label` styled as a pill: accent background, white 10px weight 600 text, radius 3, padding 0×5). If the day has at least one **high-impact** event *among the currently filtered events*, add a red dot (`Circle` r=3, `high` colour, tooltip "High-impact release").
  - **Line 2:** the count, e.g. `58 events` / `1 event`, in 11.5px `muted`.
- **The first tab is the week.** Its label is the week's dates instead of a day:

  | Week | Label |
  |---|---|
  | Within one month | `Oct 18 – 24, 2026` |
  | Across two months | `Oct 25 – Nov 7, 2026` |
  | Across two years | `Dec 27, 2026 – Jan 2, 2027` |

  Its count is the total for the whole week.
- **The other tabs** are the seven days, `Sun 18` … `Sat 24`.
- **Selection:**
  - The selected tab uses the "default button" fill (`def-top`→`def-bot` gradient, white text, inset shadow).
  - The week tab is selected by default.
  - Clicking a day narrows the table to that day. Clicking the selected day again, or the week tab, shows the whole week again.
  - The selection can't become empty: if a click would deselect everything, re-select the week tab.
- **Dimming:** days before today show their label in `muted` at weight 500, and so does the week tab's label when it isn't selected.
- **Counts follow the filters** (countries, impact, categories, search).

### 7.3 Filter line

An `HBox` with the filters on the left and the actions on the right, separated by a spacer.

**Shared look.** Every dropdown on this line is a flat **plain-text dropdown**: a grey label, then the value in weight 600, then ▾, at 12.5px, with no border or background. The value turns `accent-text` on hover. Show the keyboard focus ring only when focus arrives from the keyboard, not after a mouse click.

| Element | JavaFX | Behaviour |
|---|---|---|
| **Countries** ▾ (e.g. "Countries G20") | `ChoiceBox` (or `ComboBox` with a custom button cell) with `Separator`s | Items, in order: **Entire world**, **G20**, **G7**, **Eurozone**, **Majors**, ─── *your custom groups (if any)* ───, **Choose countries…**, **Edit groups…**. Choosing a preset replaces the country selection (one preset at a time). "Choose countries…" opens §8.1 and leaves the shown value unchanged. "Edit groups…" opens Settings → Country groups. After Choose countries, the value shows the country's name when one country is picked (e.g. "Japan"), or `N countries`, with a tooltip listing them. Default: **G20**. |
| **Impact** ▾ | `MenuButton` with `CheckMenuItem`s (or `CustomMenuItem` with a `CheckBox`) | Menu: "Select all", "Clear", separator, then **High**, **Medium**, **Low**. Each item shows the small impact bars before its label and the count on the right. The menu **stays open** while toggling. Button value: `All`, `None`, the single label, or `N selected`. |
| **Categories** ▾ | same as Impact | Items in display order (§5.3), with **Holiday first, then a separator**, then the rest. Default: All. Unticking Holiday hides holidays; "Clear" followed by ticking Holiday shows holidays only. |
| **Reset filters** | `Hyperlink` | Visible only when something differs from the defaults (Countries G20, Impact All, Categories All, empty search). Resets those. It doesn't change the week or the selected day. Tooltip: "Back to G20, all impact levels and categories, no search". |
| *(warning area)* | `Label`, `amber` colour | Empty normally. Shows data warnings (§9). |
| **This Week** | `Button` | 28px tall, 12.5px text. **Disabled** (greyed) while the current week is showing. Jumps to the current week and selects the week tab. Tooltip: "Back to this week". |
| Search | `TextField` with prompt "Search events", the `search` icon on the left, and an ✕ clear button on the right shown only when there's text | 220px wide, 28px tall. Filters live as the user types. Esc clears it. |
| ⟳ Refresh | `Button` with the `refresh` icon, transparent, like ⚙ | See §9. |

### 7.4 Events table

**Control.** Use a `TreeTableView<RowItem>` with the root hidden. Each **day** is a parent `TreeItem` and its events are the children, so the disclosure arrow and folding are built in. Column widths:

| Column | Width |
|---|---|
| Time | 76 |
| Country | 170 |
| Impact | 96 |
| Event | grows |
| Actual | 100 |
| Forecast | 100 |
| Previous | 100 |
| Alert | 60 |

Make the columns non-sortable, and keep the header style flat (§11).

**Day rows**
- The header shows `▼ Thursday, Oct 22, 2026 [Today]` in 12.5px weight 600 on the `day` background colour.
- The count (`48 events`, 12px, `muted`) is **right-aligned so it ends at the right edge of the Impact column**, less 8px of padding.
- **A day row needs to look like one full-width bar.** `TreeTableView` can't span columns natively, so use a custom `setRowFactory` / `TreeTableRow` that draws day rows as a single full-width node: arrow, date, Today chip, and the count positioned at `76 + 170 + 96 − 8` px. That's the main piece of custom work in this module. As a simpler fallback, put the date and chip in the first column and the count in the Impact column, with the first column's text allowed to overflow, or with Time and Country widened.
- **Folding.** Clicking a day row, or pressing ←/→ on it, folds and unfolds it.
  - **Starting state:** when showing the **current week** with no single day selected, days **before today start folded**, and today and later days start expanded. Every other week starts fully expanded.
  - **User choices override this** until the week changes.
- Days with no matching events don't appear.

**Event rows** (cell padding 4px × 8px, 13px text, weight 500; alternate rows use the `row-alt` background; hovering a row uses `row-hover`):

| Column | Content |
|---|---|
| **Time** | `HH:mm` in the display zone, or `All day` for holidays. Shown `muted` when released or past (§5.4). |
| **Country** | Flag `ImageView` (16px, round) + name. Tooltip: the name. |
| **Impact** | Three small bars (`Region`s 3px wide, 5/8/12px tall, gap 2px) + `High` / `Med` / `Low` in 11.5px `muted`. High colours all three bars `high`, Medium colours two bars `med`, Low colours one bar `low`. The rest are `faint`. Tooltip: "High impact". |
| **Event** | The name, with ellipsis if too long. Tooltip: `name · category`. Holidays in italics. |
| **Actual / Forecast / Previous** | Right-aligned, tabular figures, formatted and coloured per §5.7. Actual is weight 600 in `fg`. |
| **Alert** | Bell `Button` (§8.2.4), centred. Empty for events without an alert. |

**Empty states** take the place of the table body, centred:

| Situation | Message |
|---|---|
| Loading | **Loading…** |
| No data for this week, offline, and no saved copy | **Can't load these dates right now.** The data service can't be reached and there's no saved copy of these dates. Retrying automatically. |
| No events this week | **No events between Oct 18 and Oct 24.** + button **Show this week** |
| Categories cleared | **No categories are selected.** + **Select all categories** |
| Impact cleared | **No impact levels are selected.** + **Select all impact levels** |
| Nothing matches | **No events match these filters.** Try widening a filter or clearing the search. + **Clear all filters** |

---

## 8. Dialogs and Settings

All dialogs are owned by `host.owner()` and modal. They have a 32px title bar in the `titlebar` colour with a 13px weight 600 title and a ✕ close button, the content area, and a `ButtonBar` footer. Esc closes.

### 8.1 Choose countries (`screenshots/08`)

A `Dialog`, about 480×640, titled "Choose countries". From top to bottom:

1. **Header row:**
   - **Countries** on the left, weight 600.
   - On the right: `N selected` (tooltip: all the names), then the `Hyperlink`s **Clear** and **Save as group…**. Both links are hidden when nothing is ticked.
2. **Search `TextField`** with prompt "Search countries" and the `search` icon. It filters the tree as you type and expands matching regions. With no matches it shows: No country matches “xyz”.
3. **`TreeView` of `CheckBoxTreeItem`s,** using `CheckBoxTreeCell`. This is the reusable **CountryTree**, also used in Settings.
   - Each **region** is a parent: ▶/▼, a tri-state checkbox, the region name in weight 600, and `n of m` on the right. Its indeterminate state is native.
   - Ticking a region ticks all its **visible** countries (the ones the search currently shows).
   - Countries are children: checkbox, flag, name. They're sorted by name.
   - Initially, only the regions containing ticked countries are expanded.
   - The list holds every country found in the loaded data plus every group member.
4. **ButtonBar:** **Cancel**, and **Apply** (the default button, disabled when nothing is ticked).

Behaviour:
- It **starts from what's shown**, so on G20 the G20 members come pre-ticked.
- **Apply** replaces the country filter with exactly those countries and no groups.
- **Save as group…** closes the dialog and opens Settings → Country groups → New group, pre-filled with the ticked countries.

### 8.2 Settings dialog

A `Dialog`, about 560×680, titled "Settings", with a `TabPane` holding **Country groups**, **Alerts** and **Display**, and a ButtonBar with **Close**.

#### 8.2.1 Country groups (`screenshots/09`, `10`)

- **Intro row:** "Custom groups show up in the country filter and work like G7 or G20." on the left, and **New group** (default `Button` with the `plus` icon) on the right.
- **YOUR GROUPS** (section header: 11px uppercase, letter-spaced, `muted`). This is a `ListView`, or a `VBox` of rows. Each row has:
  - the name in weight 600 and `N countries`
  - up to 8 flags plus `+N`
  - on the right, `pencil` (Edit) and `trash` (Delete) icon buttons
  - Empty state: No custom groups yet. Create one, such as “My Trading Countries”.
- **BUILT-IN GROUPS:** the same rows, plus a `Built-in` tag and the description. Each has a `copy` icon button, "Duplicate as custom group", which opens the editor with the name `"<name> (copy)"`, made unique.
- **Delete** opens a confirmation `Alert` (§8.3): title "Delete group", header `Delete “<name>”?`, message "This group will be removed. This can't be undone.", buttons **Cancel** (focused by default) and **Delete**.
- **Group editor,** which replaces the list while editing:
  - heading `NEW GROUP` / `EDIT GROUP`
  - **Group name** `TextField` (max 40 characters, prompt "e.g. My Trading Countries")
  - **Countries** header with `N selected` and **Clear**
  - a "Search countries" field and a **CountryTree** (about 300px tall)
  - an error `Label` (§5.5 messages)
  - **Cancel** / **Save group**

  Saved groups appear straight away in the Countries dropdown.

#### 8.2.2 Alerts (`screenshots/11`, `12`)

All alerts come from **one rule**. Individual events can't be picked.

From top to bottom:

1. **☐ Turn on alerts** (`CheckBox`, bold). **Default: on.**
2. **Summary label** (`muted`):
   - On: **On:** alerts go off 10 minutes before upcoming High-impact events in United States, in any category.
   - Off: Off. When on, alerts go off …
   - Wording rules:
     - lists use `A or B` / `A, B or C`
     - impacts are capitalised followed by `-impact`
     - an empty country list reads `in any country`
     - empty categories read `in any category`
     - a lead time of 0 reads `at the time of`
3. **ALERT ME ABOUT** section, dimmed to 60% opacity while alerts are off but still editable. Under it: "An event needs to match every part. Leave a part empty to include everything." It has three parts:
   - **Countries:** `N selected` (or `Any country` when empty) with **Clear**, then a "Search countries" field and a **CountryTree** (about 220px). Default: **United States**.
   - **Impact:** `CheckBox`es High, Medium, Low in a row. Default: **High**.
   - **Categories:** `CheckBox`es for every category **except Holiday**, in display order, in two columns. Default: **none ticked, which means any category**.

   **Rule semantics:** an event must match **every** part, and a part with nothing ticked means **any**. Changes apply **immediately**, with no Save button.
4. **ALERT LEAD TIME:**
   - A `Spinner<Integer>` (or a numeric `TextField`) and a `ChoiceBox` with minutes, hours and days, then "before each event".
   - Below them: "Alerts go off **10 minutes before**." and a **Save** button.
   - Validation messages:
     - Enter a whole number of 0 or more.
     - Choose minutes, hours or days.
     - That's more than 30 days. Use at most N <unit>.

     The maximum is 30 days in any unit.
   - Default: **10 minutes**.
5. **YOUR ALERTS:**
   - Three stat boxes: **Waiting** (armed), **Needs acknowledgment** (triggered), **Triggered** (acknowledged).
   - A **Clear triggered alerts** `Hyperlink`, shown when Triggered > 0. It opens a confirmation:
     - title "Clear triggered alerts"
     - header `Clear N triggered alert(s)?`
     - message "Their grey bells disappear from the table. Alerts that are still waiting aren't affected."
     - buttons **Cancel** / **Clear**
   - An **Acknowledge all** `Button`, shown when Needs acknowledgment > 0.
   - Empty states: "No upcoming events match right now." when on, "Alerts are off." when off.
6. **Note:** "Alerts only run while the app is open. Alerts whose time came while it was closed go off when you open it again." (The prototype says "browser tab". Reword it for the desktop app.)

#### 8.2.3 Display (`screenshots/13`)

- **APPEARANCE:** `RadioButton`s **Dark** (default), **Light** and **Match my computer**, with the note "Dark is the default. “Match my computer” follows your system’s light or dark setting." If the host app owns the theme (`host.hostTheme() != null`), **hide this section** and follow the host.
- **TIME ZONE:** a **Default time zone** `ComboBox` (the same list and separators as the title line), with the note "Used whenever the calendar opens. The time zone above the table changes it for the current session only." Changing it saves it and also switches the current view.
- **ACTUAL AND PREVIOUS VALUES:** "Colors for positive and negative numbers in the Actual and Previous columns." `RadioButton`s:
  - **Blue / pink** (default): dark theme `#add8e6` / `#ffc0cb`, light theme `#1f6fae` / `#c2185b`
  - **Green / red:** the theme's `pos` / `neg` (§11)
  - **Custom:** two `ColorPicker`s, **Positive** and **Negative**, each showing its hex code

  A **Preview** row shows sample values: `3.7%`, `-1.4%`, `250`, `-0.448`.

#### 8.2.4 Bells (in the Alert column)

Bells only display state. They're not toggles.
- **Alerts off:** no bells at all.
- **Alerts on:**
  - An **armed** event shows a **filled bell in `alert-edge` (yellow)**, with the tooltip `Alert set for <Country> <Event>, goes off in 3 hours. Click for alert settings`.
  - A **triggered or acknowledged** event shows a **filled bell in `faint` (grey)**, with the tooltip `Alert for <Country> <Event> triggered. Click for alert settings`.
  - Any other event has no bell.
- **Clicking any bell** opens Settings on the **Alerts** tab and changes nothing else.
- A row whose alert is **triggered** (still needing acknowledgment) gets the `alert-bg` background.

### 8.3 Confirmation

A JavaFX `Alert(AlertType.CONFIRMATION)` (or an equivalent styled `Dialog`) with a title, header text, a content message, and buttons **Cancel** + an action. **Cancel is the default and focused button**, so a stray Enter never confirms a destructive action.

### 8.4 Alarm (`screenshots/15`)

A modal `Dialog` titled **Alert**. It **can't be dismissed** except with **Acknowledge**: no ✕, and Esc doesn't close it.

- **Header:** `Report alert`, or `N report alerts`, with an animated ringing bell icon on the right (`alert-edge` on a tinted circle).
- **List,** one entry per triggered alert:
  - flag + `<Country> · <Event>` in weight 600
  - `Scheduled Friday, Oct 23, 2026, 08:46 (UTC−4)`
  - the time left, updated every second, in `alert-edge` weight 600: `7 minutes 20 seconds until the report`, `Released`, or `due now`
- **Footer:** an **Acknowledge** default button, which acknowledges **all** the listed alerts.
- **Updates:** new alerts that trigger while it's open are added to the list.
- **Other dialogs:** opening the alarm closes any open menus and the Settings dialog.
- **Host badge:** expose the triggered count through `triggeredAlertCountProperty()`, so the host can badge its tab or window title as `(2) Economic Calendar`.
- **Accessibility:** announce the alarm to screen readers via its accessible text.

---

## 9. Data refresh and offline copy

Our server does all the timing (scheduled refreshes, and a refresh about 60 seconds after each release). The client only asks whether the data changed. Full design: `DATA-SERVER.md` §4.

**Startup**
1. If a saved snapshot exists, show it immediately, and use its ETag for the first poll.
2. Then poll straight away.

**Polling, every 60 seconds**
- Send `If-None-Match` with the version held.
- **304:** do nothing.
- **200:** replace the whole dataset, save it as the offline copy, re-sync alerts (§10) and rebuild the view. **Keep** the user's week, selected day, folding and filters.
- After each successful poll, clear any warning and set the refresh tooltip to `Refresh · last updated HH:mm` (the snapshot's `updatedAt` in the display zone).

The client **never** fetches individual weeks, schedules its own release polls or merges data.

**Release state still updates locally.** The 15-second clock tick greys times that have passed and checks alerts (§5.4, §10), with no network call.

**⟳ Refresh button**
- Click: an immediate poll, which also restarts the 60-second timer.
- While polling, the icon **spins** (a `RotateTransition`) and the button is disabled.
- Afterwards the button stays **disabled for 10 seconds**, dimmed.
- Tooltips:

  | State | Tooltip |
  |---|---|
  | Polling | Refreshing… |
  | Live data | Refresh · last updated HH:mm |
  | Showing the saved copy | Refresh · showing data from Oct 22, 13:53 |

**Week navigation limits**
- **‹** is disabled on the week that contains the dataset's `from` date, and **›** on the week that contains its `to` date.
- Their tooltips then say which dates are available: `Calendar data is available from Sep 22 to Dec 22`.
- **This Week** works as before (disabled only while the current week is showing).

**Offline copy**
- Save **one** snapshot: the latest 200 body (or its parsed form), its ETag, and the time it was saved, through `SettingsStore` or a file in the app's data folder.
- If the saved snapshot's window doesn't include the current week (it's very old), show the can't-load state for weeks outside it.

**Failures** (the warning label sits at the right of the filter line, in `amber`):

| Situation | Behaviour |
|---|---|
| Live data was loaded this session | Keep it. Warning: `Update failed at HH:mm; showing data from HH:mm. Retrying automatically` |
| Otherwise, a saved snapshot exists | Show it. Warning: `Can't reach the data service. Showing data from Oct 22, 13:53. Retrying automatically` |
| Neither | Warning: `Can't load the calendar right now. Retrying automatically`, plus the empty state "Can't load these dates right now." (§7.4) |
| Server says 401 / 403 | Keep any data shown. Warning: `The data service rejected this app's access. Contact support` |

**Automatic retries** carry on at the next 60-second poll. When a poll succeeds again, the warning clears.

---

## 10. Alerts engine (`reference/js/core/alerts.js`) and persistence

**States per event id:** `none → armed → triggered → acknowledged`.

**Rule:** `{enabled, countries[], impacts[], types[]}`.
- **Default:** enabled, `countries=["US"]`, `impacts=["high"]`, `types=[]` (empty means any).
- **Match:** an event matches when every non-empty list contains its value.

**sync(events)** runs after every data load and every settings change:
- **If enabled,** arm every event that:
  - matches the rule
  - isn't a duplicate
  - isn't a holiday
  - is in the future (`ts > now`)
  - has no state yet

  Store `{state:"armed", eventTs, label, country, impact, type}`.
- **Always:** remove `armed` entries that no longer match the rule, or all of them when alerts are disabled. The stored country, impact and type let this be re-checked even for events not currently loaded.
- **Never touch** `triggered` or `acknowledged` entries.

**check()** runs every 15s, after sync, and after a lead-time change:
- Every `armed` entry with `now >= eventTs − lead` becomes `triggered` (recording `firedAt`), and the alarm opens.
- Only `armed` can trigger, so nothing fires twice.
- If the app was closed through an alert time, the alert fires on the next check after opening.

**Acknowledge / Acknowledge all:** `triggered` becomes `acknowledged`.

**Clear triggered alerts:** deletes the `acknowledged` entries.

**Retention:** acknowledged entries whose event is more than **30 days** old are deleted whenever state is saved.

**Lead time:** 0 or more, at most 30 days. Default 10 minutes.

**Alerts arm across the whole dataset,** about two months ahead, as soon as it loads. The user doesn't have to visit a week first.

### Persistence (`SettingsStore`)

Default to `java.util.prefs.Preferences` (node per user), unless the host app has its own settings system. The prototype's localStorage keys show what's saved.

**Saved:**

| What | Contents |
|---|---|
| `prefs` | `{defaultZone, valueColors:{mode, pos?, neg?}, theme}` |
| `customGroups` | custom country groups |
| `alertSettings` | `{lead:{value,unit}, enabled, rule:{countries,impacts,types}}` |
| `alertStates` | `{id → state}` |
| `calendarSnapshot` | the one offline snapshot, its ETag and when it was saved (§9). It may be a file in the app's data folder instead. |

**Not saved:** the Countries filter, Impact, Categories, search, the selected week or day, and the session time zone. Every launch starts at the defaults: current week, G20, All, All, empty search, the default zone.

---

## 11. Theme and CSS

Write one stylesheet scoped under a root style class (e.g. `.econ-calendar`), using **looked-up colours** so dark and light are a single class switch:

```css
.econ-calendar { -ec-bg: #1e1e1e; -ec-fg: #ffffff; /* … dark tokens … */ }
.econ-calendar.light { -ec-bg: #f5f6f7; -ec-fg: #17202a; /* … light tokens … */ }
.econ-calendar .label { -fx-text-fill: -ec-fg; }
```

**Tokens.** These are copied from `reference/css/app.css` `:root`, which also has the light block:

| Token | Dark | Light | Used for |
|---|---|---|---|
| bg | #1e1e1e | #f5f6f7 | page background |
| panel / panel-2 | #262626 / #323232 | #ffffff / #eef0f2 | surfaces, chips |
| row / row-alt / row-hover / day | #1e1e1e / #232323 / #303030 / #2b2b2b | #ffffff / #f7f8f9 / #eef3f8 / #e9ecef | table rows, day rows |
| fg / muted / faint | #ffffff / #a6a6a6 / #767676 | #17202a / #5d6b78 / #8a96a1 | text levels; grey bell = faint |
| line / line-strong | #303030 / #3c3c3c | #e1e6ea / #c9d1d8 | borders |
| accent / accent-text / accent-soft | #28557d / #8fbce6 / #233547 | #28557d / #28557d / #e3ecf5 | fills / links / soft fills |
| high / med / low | #ff7b6b / #e8b04a / #8a8a8a | #c0392b / #b07000 / #8a96a1 | impact bars, red dot |
| amber | #e2b453 | #8a5a00 | warnings |
| alert-bg / alert-edge | #2b2412 / #e0a92e | #fff5d9 / #d39a00 | triggered row / yellow bell, alarm |
| pos / neg (Green/red mode) | #3fb950 / #ff7b6b | #1a7f37 / #c0392b | value colours |
| btn-top / btn-bot / btn-border | #3d3d3d / #333333 / #4d4d4d | #fdfdfd / #e7e7e7 / #b6b6b6 | buttons (vertical gradient) |
| btn-hover-top/bot | #474747 / #3c3c3c | #ffffff / #efefef | button hover |
| btn-press-top/bot | #2b2b2b / #313131 | #d9d9d9 / #e3e3e3 | pressed |
| def-top / def-bot / def-border | #33689a / #28557d / #1d4466 | #3a76ab / #28557d / #1d4466 | default buttons, selected day tab |
| field / field-border | #2a2a2a / #4d4d4d | #ffffff / #b6b6b6 | text fields |
| menu / menu-border / titlebar | #2d2d2d / #4d4d4d / #2b2b2b | #ffffff / #bdbdbd / #e9e9e9 | menus, dialog title bars |
| head-top / head-bot / head-sep | #333333 / #282828 / #3d3d3d | #f7f7f7 / #e6e6e6 / #c9c9c9 | table header gradient, separators |
| focus | #5aa0dd | #039ed3 | focus ring |

**The look is Modena, recoloured:**
- Buttons have a 3px radius, a vertical gradient (`btn-top`→`btn-bot`), a 1px border, and a faint top highlight.
- Default buttons use the `def` gradient with white text.
- Table headers use the `head` gradient with **centred, normal-case** 12.5px weight 600 labels, 6×8px padding, and 1px `head-sep` column separators.
- Dialog title bars use `titlebar`.
- The focus ring uses `focus`, and appears for keyboard focus only.

**Text sizes:**

| Element | Size and weight |
|---|---|
| Body | 13px |
| Title | 20px, weight 600 |
| Filter line | 12.5px |
| Section headers in Settings | 11px uppercase, weight 600, `muted`, letter-spaced |

**If the host app already has a dark/light theme,** map these tokens onto its palette where they correspond (backgrounds, text, accent), and keep the calendar-specific ones (impact, alert, value colours).

---

## 12. Assets

- **Fonts:** load `assets/fonts/Inter-Regular.ttf`, `Inter-Medium.ttf` and `Inter-SemiBold.ttf` at startup with `Font.loadFont(getClass().getResourceAsStream(...), 13)`. Use `-fx-font-family: "Inter"` with weights 400, 500 and 600. The licence (SIL OFL) must ship with them.
- **Flags:** `assets/flags/<code>.png` (lower-case ISO-2, e.g. `gb.png`, `eu.png`).
  - They're 64×64 squares. Display them at 16px (20px in dialogs), clipped to a circle (`Circle` clip, or `ImageView` + a rounded clip).
  - Cache the `Image`s.
  - For a missing code, show an empty circle. `WW` uses the globe icon.
  - Licence: MIT (flag-icons).
- **Icons:** `assets/icons/icons.json` maps names to SVG path data on a 24×24 viewBox.
  - Build each as `SVGPath`s (one per entry in `paths`), stroked with the text colour at the given `strokeWidth`, with round caps and joins, and filled when `fill` is true.
  - Scale to 16–20px.
  - `menu-arrow` is a filled 8×5 triangle for dropdowns.
  - Icons come from Lucide (ISC licence).

---

## 13. Keyboard and accessibility

- Everything is reachable with Tab, and the focus ring shows only for keyboard focus.
- Dropdown menus open with Down or Enter, move with the arrow keys, toggle with Space, and close with Esc.
- Day rows fold with ←/→. Dialogs close with Esc, except the alarm.
- Give icon-only buttons an accessible text and a tooltip:
  - Settings
  - Refresh · last updated…
  - Previous week, Next week
  - Clear search
  - Close
  - each bell's tooltip text
- Day tabs' accessible text is `Thursday, Oct 22, 2026 (today), has a high-impact release: 58 events`. The week tab's is `Whole week, Oct 18 – 24, 2026: 220 events`.

---

## 14. JavaFX notes and the custom parts

These are the parts that need more than configuration. They're described with standard JavaFX controls. With the host's own components (integration file), the same behaviour is needed, and any part a host component can't do is listed there as a gap:
1. **Full-width day rows** in `TreeTableView` (§7.4): a custom row factory.
2. **Day bar tabs** (§7.2): `ToggleButton` graphics with the chip and dot, and joined segment styling.
3. **Multi-select menus that stay open** (§7.3): use `CustomMenuItem` with `setHideOnClick(false)` holding a `CheckBox` and a count `Label`.
4. **Plain-text dropdowns** (Countries, Impact, Categories, time zone): CSS to strip the `ChoiceBox`/`MenuButton` background and border, keeping the arrow.
5. **CountryTree:** `TreeView` + `CheckBoxTreeItem` + a cell factory adding the flag and the `n of m` count, with a text filter (rebuild the visible children, or wrap them in a `FilteredList`).
6. **Alarm countdown:** a 1-second `Timeline` while the dialog is open.

---

## 15. Build phases

Work in these phases. Each ends with checks from `tests.md`. Stop after each phase for review.

0. **Setup** (`SETUP.md`): scan the host app, send one questionnaire (placement, component map, server URL and auth, host services, extras), write `econocalendar-integration.md` and get it confirmed once. No other code before that.
1. **Setup and data layer**
   - Package, `CalendarHost`, the `Controls` factory from the component map, `CalendarDataSource` with `FixtureDataSource` and `ServerDataSource` (§4.2), and the local stub server if setup chose it.
   - `EventNormalizer`: ids, holidays, duplicates, **categories**. `CalendarTime`: weeks, labels, zones.
   - Unit tests: T1–T6.
2. **Main view skeleton:** the title line, week bar (‹ ›, eight tabs with counts, the week-range label) and This Week. Tests: T7–T9.
3. **Events table:** a `TreeTableView` with day rows, folding rules, all cell formats and colours, empty states. Tests: T10–T13.
4. **Filters:** Countries dropdown, Impact and Categories menus with counts, search, Reset filters. Tests: T14–T18.
5. **Dialogs:** Choose countries + CountryTree, Settings (groups and the group editor, Display), Confirm. Tests: T19–T23.
6. **Alerts:** engine, Settings → Alerts, bells, alarm, Clear triggered, persistence. Tests: T24–T30.
7. **Refresh and offline:** the 60-second poll with ETag/304, the Refresh button, week limits, the offline snapshot and warnings, against the stub or the real server. Tests: T31–T35.
8. **Theme and polish:** dark/light CSS, Inter, focus rings, tooltips, a pixel check against `screenshots/`. Tests: T36–T38.

---

## 16. Where to look in `reference/`

| Topic | File |
|---|---|
| Category rules (exact regexes), holiday test, release state (`releaseState`) | `js/core/events.js` |
| Weeks, labels, zone list, countdown wording | `js/core/time.js` |
| Filters and counts | `js/core/filters.js` |
| Alert engine, rule wording (`describeRule`), lead validation | `js/core/alerts.js` |
| Main wiring: week logic, warnings, empty states (its refresh and caching are web-only, §17) | `js/app.js` |
| Table rows, day headers, bells, number formatting | `js/ui/table.js` |
| Settings tabs and their wording | `js/ui/settings.js` |
| Choose countries / CountryTree | `js/ui/country-picker.js`, `js/ui/country-tree.js` |
| Multi-select menus | `js/ui/multiselect.js` |
| Alarm, Confirm | `js/ui/alarm.js`, `js/ui/confirm.js` |
| Countries, regions, built-in groups | `js/core/countries.js`, `js/data/country-groups.js`, `js/core/groups.js` |
| Every colour and size | `css/app.css` (`:root` tokens; the "JavaFX-native skin" section; ignore `@media (max-width: 560px)`) |
| Markup and order of elements | `index.html` (ignore `#login` and the hidden `#logout`) |

## 17. Not part of the Java version

- Login, logout and the password, plus the `auth.js`, `vault.js` and `credentials.js` files (they weren't copied).
- Mobile and phone layout.
- The browser-specific parts: CORS, `?token=`, localStorage (use `SettingsStore`), the hidden native date input, and web fonts.
- The prototype's data handling: it calls the provider directly for each week, polls after releases, merges results and keeps 4 cached windows (`js/services/finnhub.js`, the refresh code in `js/app.js`). The Java client polls our server instead (§4, §9).
- Date pickers: the prototype once had date fields; the final version has none.
