# Setup: confirm components, endpoint and host services

**For:** Claude, working with the Java developer. Run this **before writing any code** (it's phase 0 in `HANDOFF.md` §15).

**Why it exists:** `HANDOFF.md` describes the calendar using standard JavaFX controls and generic services. The developer's app has **its own components** that replace the standard ones, and the calendar's data comes from **our server on Google App Engine**, not from the data provider. This step finds out what to use for each part, gets it confirmed **once**, and writes it down so every later phase builds on the same decisions.

**How it works:**
1. **Scan** the host codebase (no questions yet).
2. **Ask everything in one message:** a questionnaire with your proposed answer filled in for every item.
3. The developer replies once: "accept" for the proposals they agree with, and corrections for the rest.
4. **Write the integration file** (`econocalendar-integration.md`, at the repository root unless the developer names another place) and show it.
5. The developer **confirms it once.** Then start phase 1.

Don't ask questions one at a time, and don't stop between sections. If something comes up later that the file doesn't cover, ask about that one thing, then add the answer to the file.

---

## Step 1. Scan the host app

Look for these, and note the class or file where you found each:

| Area | What to find |
|---|---|
| Build | Java and JavaFX versions, build tool (Maven/Gradle), modules (`module-info.java`), how resources are packaged |
| Layout | Package naming, where features live, how a feature is opened (menu item, tab, docked panel, window) |
| **Components** | The app's own control library: classes extending `Control`, `Region` or `Skin`, factory or builder classes, and any wrappers around standard controls. Note which standard control each one replaces. |
| Theme | Stylesheets, colour tokens or looked-up colours, dark/light switching, the app's font |
| Icons | An existing icon set or icon factory |
| Settings | How the app saves user settings (its own store, `java.util.prefs`, files) |
| Networking | HTTP client in use, proxy configuration, timeouts, retry helpers |
| **Auth** | How the app identifies itself to its own servers: a licence key, login token or session, and the class that supplies it |
| JSON | Jackson, Gson or other |
| Background work | Executors, schedulers, how results get back to the FX thread |
| Notifications | Existing sound, tray or toast notifications (for the alert alarm) |
| Logging | Logging framework |
| Tests | JUnit version, TestFX, mocking library |

## Step 2. Ask everything at once

Send **one message** with the sections below. Fill in a **proposed answer** for every item from the scan. Where the scan found nothing, propose the `HANDOFF.md` default and say so. Number the items so the developer can reply by number.

### A. Placement

1. Package for the calendar module.
2. How the user opens it (menu item, tab, docked panel, window) and where it's wired in.
3. Does the host show a badge or count anywhere (for triggered alerts, `HANDOFF.md` §8.4)?

### B. Components

A table with one row per role below. For each one, propose **the developer's component** if there is one, otherwise the standard JavaFX control. Flag any role where their component **can't do** what the spec needs (for example, a menu that must stay open while ticking items), and propose how to handle it.

| # | Role | Where it's used | Standard JavaFX default |
|---|---|---|---|
| B1 | Push button | This Week, dialog footers, New group, Save | `Button` |
| B2 | Default (primary) button | Apply, Save group, Acknowledge | `Button` with `setDefaultButton(true)` |
| B3 | Icon-only button | ⚙ Settings, ⟳ Refresh, pencil, trash, copy, search ✕ | `Button` with an `SVGPath` graphic |
| B4 | Week arrows | ‹ › beside the day bar | `Button` |
| B5 | Segmented day bar | The week tab + seven day tabs (§7.2) | `ToggleButton`s in a `ToggleGroup` |
| B6 | Plain-text dropdown | Time zone, Countries | `ChoiceBox` or `ComboBox` |
| B7 | Multi-select menu that stays open | Impact, Categories | `MenuButton` + `CustomMenuItem` + `CheckBox` |
| B8 | Link | Reset filters, Clear, Save as group…, Clear triggered alerts | `Hyperlink` |
| B9 | Search field with icon and clear button | Search events, Search countries | `TextField` + graphics |
| B10 | Text field | Group name | `TextField` |
| B11 | Number input | Alert lead time | `Spinner<Integer>` |
| B12 | Check box | Turn on alerts, impact and category ticks | `CheckBox` |
| B13 | Radio buttons | Appearance, value colours | `RadioButton` + `ToggleGroup` |
| B14 | Colour picker | Custom value colours | `ColorPicker` |
| B15 | Grouped events table | The main table with day rows (§7.4) | `TreeTableView` |
| B16 | Tree with check boxes | CountryTree (§8.1) | `TreeView` + `CheckBoxTreeItem` |
| B17 | List of rows | Country groups list | `ListView` or `VBox` |
| B18 | Tabs | Settings: Country groups, Alerts, Display | `TabPane` |
| B19 | Modal dialog | Choose countries, Settings, Alarm | `Dialog` |
| B20 | Confirmation | Delete group, Clear triggered alerts | `Alert(CONFIRMATION)` |
| B21 | Tooltip | Everywhere | `Tooltip` |
| B22 | Label, chip, separator | Today chip, counts, section headers | `Label`, `Separator` |
| B23 | Icons | All icons | `SVGPath` from `assets/icons/icons.json` |
| B24 | Flags | Country column, dialogs | `ImageView` from `assets/flags/` |

### C. Data endpoint (our App Engine server)

The client calls **only our calendar server** on Google App Engine (`DATA-SERVER.md` §3.5, `DEPLOY-APP-ENGINE.md`). It never calls the data provider and never holds its API key.

1. **Server status:** already deployed, or still to be built? If it's still to be built: in this repository or a separate one, and should it be built in this session?
2. **Base URL** for each environment (development, staging, production), and where the app reads it from (config file, build property, settings).
3. **Auth:** how the app proves itself to the server. Name the host class that supplies the token (`Authorization: Bearer <token>`), and what should happen when it's missing or expired.
4. **Proxy and network settings** the app already applies to its own requests (reuse them).
5. **Until the server exists:** develop against the fixture data source (`test-data/sample-calendar.json`), plus a small local stub that serves the same file with ETag/304, so the client code doesn't wait for the server. Confirm or change.

### D. Host services

1. **Settings storage:** which store, and under what key or node (default `java.util.prefs`, `HANDOFF.md` §10).
2. **Theme:** does the host own dark/light? If yes, the Display → Appearance section is hidden and the calendar follows the host (§11). Which host tokens map to the calendar's tokens?
3. **Font:** the host's font, or bundled Inter (§12)?
4. **Icons:** the host's icon set, or the bundled `icons.json`?
5. **Background work:** which executor or scheduler to use for polling and timers.
6. **Alarm:** a dialog only (the default), or also the host's sound or notification?
7. **Logging:** which logger.
8. **Clock and time zone:** inject a `Clock` for tests (required by `tests.md`). Use the host's time-zone setting, if it has one, as the default zone.

### E. Extra classes and scope

1. Any other existing classes the calendar should **use** (base views, dialog helpers, validation, formatting, i18n).
2. Anything to **leave out** or postpone (for example custom country groups, or the light theme).
3. Code conventions to follow (naming, nullability annotations, records, formatting).
4. Anything else the developer wants included.

## Step 3. Write the integration file

After the developer replies, write `econocalendar-integration.md` with the final answer for every item, in the same sections (A–E), and these extra parts:

- **Component map:** the B table with a final "Use" column (fully qualified class names), and a note on any gap and how it's handled.
- **Gaps and deviations:** anything that will look or behave differently from `HANDOFF.md`, `tests.md` or `screenshots/` because of a host component or choice, so the acceptance checks can be read accordingly.
- **Open items:** anything still unknown (for example the production URL), and what's used meanwhile.

Show the file and ask for **one confirmation**. Apply any corrections, then start phase 1.

## Precedence

1. `econocalendar-integration.md` (the confirmed answers)
2. `DATA-SERVER.md` for anything about data, the server and refresh
3. `HANDOFF.md`
4. `reference/` (the web prototype), only for exact rules and wording

Wherever `HANDOFF.md` names a standard JavaFX control, read it as **the role**, and use the class the integration file maps to that role. The **behaviour** described (keyboard use, wording, states, sizes, colours) still applies whichever component is used, except where the integration file records a gap.
