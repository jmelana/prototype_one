# Economic Calendar: JavaFX handoff package

This folder has everything needed to rebuild the Economic Calendar web prototype as a **JavaFX module inside your existing app**, working with Claude.

## How to use it

1. Copy this whole `javafx-handoff/` folder into the root of the existing JavaFX app's repository.
2. Open Claude Code at the repository root.
3. Paste the **opening prompt** from `HANDOFF.md` (section 0).
4. **Setup (one round of questions).** Claude scans your codebase, then sends one questionnaire with a proposed answer for everything it needs to know (`SETUP.md`):
   - where the calendar goes and how users open it
   - which of **your components** to use for each control (buttons, dropdowns, the table, dialogs and so on)
   - **our calendar server** on Google App Engine: its URL per environment, how the app authenticates, and whether it's deployed yet
   - which of your services to reuse (settings, theme, icons, executors, logging, notifications)
   - any other classes to include, and anything to leave out
5. Reply once: accept the proposals or correct them. Claude writes `econocalendar-integration.md` with the answers. Confirm it, and that file guides the rest of the build.
6. Claude then builds **one phase at a time** (`HANDOFF.md` §15). After each phase, run that phase's checks in `tests.md`, and tell Claude about anything that doesn't match before moving on.

## What's inside

| Item | Purpose |
|---|---|
| `SETUP.md` | Phase 0: the setup questionnaire and the integration file it produces |
| `HANDOFF.md` | The full specification and build plan, written for Claude |
| `DATA-SERVER.md` | **How data flows:** our server is the only caller of the data provider, and clients poll it |
| `DEPLOY-APP-ENGINE.md` | How that server runs on Google App Engine: cron schedule, Cloud Storage, Secret Manager, `app.yaml`, setup steps, costs |
| `tests.md` | Acceptance checks with exact expected values from the sample data |
| `screenshots/` | The look to match (17 images, dark and light) |
| `reference/` | The web prototype's source: reference only, for exact rules and wording |
| `assets/` | Inter TTF fonts, 271 flag PNGs and SVG icon paths, all bundled (no outside requests) |
| `test-data/` | A real calendar response for tests and offline development |

## Already decided

- **Data:** the app talks only to our calendar server on Google App Engine. The data provider's API key lives only on that server.
- **Components:** your own components replace the standard JavaFX ones wherever you have them. Setup records the mapping.
- **Theme:** if your app already controls dark/light, the calendar follows it (`HANDOFF.md` §11).
- **Settings storage:** your app's settings system if it has one, otherwise `java.util.prefs` (`HANDOFF.md` §10).

## Licences of bundled assets

| Asset | Licence | File |
|---|---|---|
| Inter font | SIL Open Font License 1.1 | `assets/fonts/LICENSE-Inter-OFL.txt` |
| Country flags (rendered from flag-icons) | MIT | `assets/flags/LICENSE-flag-icons.txt` |
| Icons (from Lucide) | ISC | Keep the attribution "Icons from Lucide (ISC licence)" in your app's third-party notices |
